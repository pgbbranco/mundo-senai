# Mundo SENAI 2026 — Front-end ao vivo

**Grupo 2 · Técnico em Informática para Internet**

## Sobre a atividade
A apresentação abordou front-end, responsividade, acessibilidade e AI Slop. O visual inicial era propositalmente bagunçado: os visitantes podiam modificar fontes, cores, espaçamentos e outros elementos por meio de um controlador interativo.

## Minha participação
Minha fala abordou AI Slop, o resultado genérico de IA usada sem direção, seus sinais e como evitá-lo com escolhas conscientes, revisão e testes.

## Materiais
- [Apresentação original](public/index.html)
- [Controlador](public/controle.html)
- [Documentação técnica original](DOCUMENTACAO-ORIGINAL.md)
- [Processo de preparação](PROCESSO.md)
- [Registro fotográfico](fotos.md)
- [Feedbacks](feedbacks.md)

## Aprendizado
A atividade relacionou decisões de design, experiência do usuário e uso criterioso da IA.

[Voltar ao portfólio](https://pgbbranco.github.io/portfolio/)
